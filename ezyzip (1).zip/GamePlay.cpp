///////////////////////////////////////////////////////////
// GamePlay.cpp
// AssignmentUnit 3
// Contains the functions for gameplay
//
// author: Akinsola Akinduro
// Date: 23.12.2020
///////////////////////////////////////////////////////////

// standard library list
#include <cstdlib>
#include <iostream>
#include <iomanip>

// header files
#include "GamePlay.h"
#include "GameBoard.h"
#include "Player.h"
#include "Characters.h"
#include "Items.h"
#include "RandomGenerator.h"

using namespace std;

//////////////////
// CONSTRUCTOR //
////////////////

GamePlay::GamePlay()
  :turnCount(1), day(false)
{

}

/////////////////
// DESTRUCTOR //
///////////////

GamePlay::~GamePlay()
{

}

//////////////////////
// OTHER FUNCTIONS //
////////////////////


////////////////////////////////////////////////////////////
// function: characterSelect()
// set the main character race
// parameter: none
// return: select - character selection
////////////////////////////////////////////////////////////
Race GamePlay::characterSelect()
{
  // declared functions
  char characterChoice;
  Race select;

  // print out for character choice
  cout << "Please chose your character:\n"
       << "(1) (H)uman\n"
       << "(2) (E)lf\n"
       << "(3) H(o)bbit\n"
       << "(4) (D)warf\n"
       << "(5) O(r)c\n"
       << "Please enter 1-5 or letter: ";

  // input of character
  cin >> characterChoice;
  switch(characterChoice) {
    // choice human
  case 'h':
  case 'H':
  case '1':
    select = Race::HUMAN;
    break;
    // choice elf
  case 'e':
  case 'E':
  case '2':
    select = Race::ELF;
    break;
    // choice hobbit
  case 'o':
  case 'O':
  case '3':
    select = Race::HOBBIT;
    break;
    //choice dwarf
  case 'd':
  case 'D':
  case '4':
    select = Race::DWARF;
    break;
    // choice orc
  case 'r':
  case 'R':
  case '5':
    select = Race::ORC;
    break;
  default:
    // default value human
    cout << "\n\tIncorrect input - default value entered (Human)\n" << endl;
    select = Race::HUMAN;
    break;
  }
  return select; // returns selected character
}

////////////////////////////////////////////////////////////
// function: selectDifficulty()
// select how difficult you want the map to be. Will change
// the amount of items, enemies and blank spaces
// parameter: none
// return: returnDiff - returns the chosen difficulty
////////////////////////////////////////////////////////////
int GamePlay::selectDifficulty()
{
  // declared functions
  char diff;
  int returnDiff;

  // print out of difficulty options
  cout << "\nPlease select a difficulty: " << endl
       << "\t(E)asy\n"
       << "\t(M)edium\n"
       << "\t(H)ard" << endl;
  cout << "Enter one of the three letters: ";

  // input of selected difficulty
  cin >> diff;
  
  switch(diff) {
    // easy
  case 'e':
  case 'E':
    returnDiff = 1;
    break;
    // medium
  case 'm':
  case 'M':
    returnDiff = 2;
    break;
    // hard
  case 'h':
  case 'H':
    returnDiff = 3;
    break;
    // returns medium difficulty if not selected
  default:
    cout << "\n\tIncorrect input - default value entered (Medium)\n" << endl;
    returnDiff = 2;
    break;
  }
  return returnDiff; // returns selected difficulty
}

//////////////////////////////////////////////////////////////////////////////
// function: selectColumns()
// set the number of columns for the board
//
// parameter: none
// return: returnValue - returns chosen numer of columns
//////////////////////////////////////////////////////////////////////////////
int GamePlay::selectColumns()
{
  // declared functions
  int returnValue;
  
  // print out to request amount of columns
  cout << "\nPlease select the number of columns for the board.\n"
       << "You'll have to enter integers between 10 and 200.\n"<< endl;

  cout << "Number of columns: ";

  // input of amount of columns
  cin >> returnValue;

  // if the value is correct - do nothing
  if (10 <= returnValue && returnValue <= 200) {
    ;
    // display error message and select default value
  } else {
    cout << "\n\tIncorrect input - default value entered (200)\n" << endl;
    returnValue = 200;
  }
  return returnValue; // returns amount of columns
}

//////////////////////////////////////////////////////////////////////////////
// function: selectRows()
// set the number of rows for the board
//
// parameter: none
// return: returnValue - returns chosen numer of rows
//////////////////////////////////////////////////////////////////////////////
int GamePlay::selectRows()
{
  // declared functions
  int returnValue;

  // print out to request the amount of rows
  cout << "\nPlease select the number of rows for the board.\n"
       << "You'll have to enter integers between 10 and 200.\n"<< endl;

  cout << "Number of rows: ";

  // input the amount of rows
  cin >> returnValue;

  // if the value is correct - do nothing
  if (10 <= returnValue && returnValue <= 200) {
    ;
    // display error message and return default value
  } else {
    cout << "\n\tIncorrect input - default value entered (200)\n" << endl;
    returnValue = 200;
  }
  return returnValue; // return amount of rows
}

/////////////////////////////////////////////////////////////////////////////
// function: dayNightCycle(actionSuccess)
// Private function for Day/Night cycle
// Print to the player if it is daytime or nightime,
// and change between daytime and nightime every 5 turn
//
// parameter: bool actionSuccess - successful move in game
// return: void
/////////////////////////////////////////////////////////////////////////////
void GamePlay::dayNightCycle(bool actionSuccess)
{
  // if five turns have passed day changes value
  if ((turnCount-1) % 5 == 0 && actionSuccess) {
    day = !day;
  }
  // if day print day info
  if (day) {
    cout << "It is daytime" << endl;
  } else { // if night print night info
    cout << "It is nightime" << endl;
  }
}

/////////////////////////////////////////////////////////////////////////////
// function: tunDetails(mainChar, actionSuccess, tileContent)
// returns character and turn details to the player
//
// parameter: Player mainChar - the players character
// parameter: bool actionSuccess - successful move in game
// parameter: what is in the tile
// return: action - the chosen action by the player. to move or investigate
///////////////////////////////////////////////////////////////////////////
char GamePlay::turnDetails(Player &mainChar, bool actionSuccess, int tileContent)
{
  // declared functions
  int posColumns, posRows;
  char action;
  
  cout << "\n---------------------------------------------\n" << endl;

  // print the turn number
  cout << "It is turn: " << turnCount << endl;

  // day and night change
  dayNightCycle(actionSuccess);

  // update the stats of the Orc player if change of cycle
  mainChar.dayNightOrc(day);
  
  // position of player both columns and rows
  posColumns = mainChar.getPlayerColumns();
  posRows = mainChar.getPlayerRows();

  // prints the position of the player
  cout << "\nYou are in position: " << "[" << posColumns << "]"
       << "[" << posRows << "]\n" << endl;

  // character details and carrying
  cout << "You are: " << endl;
  mainChar.printPlayerStat();
  
  // lets the player know what is in the tile when they move
  // to the tile
  cout << "\nYou have come across ";

  // 0 = empty
  if (tileContent == 0) { 
    cout << "an empty field" <<endl;
  }
  // 1 = human
  else if (tileContent == 1) { 
    cout << "a Human, he seems angry" <<endl;
  }
  // 2 = elf
  else if (tileContent == 2) { 
    cout << "an Elf, but not the good kind!" <<endl;
  }
  // 3 = dwarf
  else if (tileContent == 3) {
    cout << "a Dwarf, he seems to be drunk and wants a brawl" <<endl;
  }
  // 4 = hobbit
  else if (tileContent == 4) {
    cout << "a Hobbit, is he a Baggins? Should I ask? " <<endl;
  }
  // 5 = orc
  else if (tileContent == 5) {
    cout << "an Orc, he just wants kill you!" <<endl;
  }
  // 6 = sword
  else if (tileContent == 6) {
    cout << "a Sword, some idiot has left their sword on the ground" <<endl;
  }
  // 7 = dagger
  else if (tileContent == 7) {
    cout << "a Dagger, its not quite a sword but it might be useful" <<endl;
  }
  // 8 = plate armour
  else if (tileContent == 8) {
    cout << "some Plate Armour, people should stop leaving things on the ground" <<endl;
  }
  // 9 = leather armour
  else if (tileContent == 9) {
    cout << "some leather Armour, that's not vegan!" <<endl;
  }
  // 10 = large shield
  else if (tileContent == 10) {
    cout << "a Large Shield, that is big!" <<endl;
  }
  // 11 = small shield
  else if (tileContent == 11) {
    cout << "a Small Shield, is it worth it?" <<endl;
  }
  // 12 = ring of life
  else if (tileContent == 12) {
    cout << "WOW! It's a Ring of Life, I've always wanted one! " <<endl;
  }
  // 13 = ring of strength
  else if (tileContent == 13) {
    cout << "THE RING OF STRENGTH! Will that look good on my finger?" <<endl;
  }
  
  // what action do you want to perform
  cout << "\nPlease choose direction N,S,E,W or\n"
       << "command (A)ttack, (P)ick up, (D)rop, (L)ook, (I)nventory or e(X)it: ";

  // input of action choice
  cin >> action;

  // returns action the player wants to do
  return action;
}

/////////////////////////////////////////////////////////////////////////////
// function: movement(move, position, max)
// moves the player a direction by adding or taking away 1 to the position
//
// parameter: char move - this is from the selected move action
// parameter: int position - current position either column or row
// return: position - returns the new row or column position of the
// main character (player)
/////////////////////////////////////////////////////////////////////////////
int GamePlay::movement(char move, int position, int max)
{
  // clear the Linux terminal using ANSI Escape Sequences
  // for a better comprehension of the game
  cout << u8"\033[2J\033[1;1H";

  switch(move) {
      // if north or west minus 1 from row or column
  case 'n':
  case 'N':
  case 'w':
  case 'W':
    if (position-1 >= 0) {
      --position;
    }
    break;
      // if south or east add 1 to row or column
  case 's':
  case 'S':
  case 'e':
  case 'E':
    if (position+1 <= max) {
      ++position;
    }
    break;
    // if a wrong value gets to this point return error
  default:
    cout << "INPUT ERROR" << endl;
  }
  // return new position of row or column
  return position;
}

/////////////////////////////////////////////////////////////////////////////
// function: currentEnenmy(tileContent)
// Gets the tile number and returns the corresponding enemy
//
// parameter: int tileContent - the enemy tile number
// return: enemy - returns the enemy on the tile
/////////////////////////////////////////////////////////////////////////////
Character GamePlay::currentEnemy(int tileContent)
{
  // declared functions
  Race enemyRace;

  // switch to determine enemy from the number in tile
  switch(tileContent) {
  case 1: // human
    enemyRace = Race::HUMAN;
    break;
  case 2: // elf
    enemyRace = Race::ELF;
      break;
  case 3: // dwarf
    enemyRace = Race::DWARF;
    break;
  case 4: // hobbit
    enemyRace = Race::HOBBIT;
    break;
  case 5: // orc
    enemyRace = Race::ORC;
    break;
  }

  // return the enemy information
  Character enemy(enemyRace);
  return enemy;
}
/////////////////////////////////////////////////////////////////////////////
// function: pickup(mainChar, content) 
// Looks to see if you can pick up item and picks it up if possible
//
// parameter: Player &mainChar - information of main character
// parameter: int content - the number of the item on the board
// return: bool actionSuccess - returns if the pick up was successful or not
/////////////////////////////////////////////////////////////////////////////
bool GamePlay::pickup(Player &mainChar, int content)
{
  // declared functions
  Items itemToPick;

  // clear the Linux terminal using ANSI Escape Sequences
  // for a better comprehension of the game
  cout << u8"\033[2J\033[1;1H";

  // printout of header
  cout << "------------ PICK UP --------------\n" << endl;
  
  // Player stats
  int weightPlayer, strengthPlayer, numberRoL, numberRoS;
  bool hasSword, hasDagger, hasShieldS, hasShieldL, hasPlate, hasLeather;

  // Player bonus stats
  int playerAB, playerDB, playerHB, playerSB;

  // Item stats
  int itemAttack, itemHealth, itemStrength, itemDefence, itemWeight;
  
  // is pick up successful?
  bool actionSuccess = false;

  // What are the bonus stats of the player?
  playerAB = mainChar.getATTB();
  playerDB = mainChar.getDEFB();
  playerHB = mainChar.getHB();
  playerSB = mainChar.getSB();

  // What is the weight of the player's inventory?
  weightPlayer = mainChar.getWeight();

  // What is the strength of the player?
  strengthPlayer = mainChar.getStrength();
  strengthPlayer += playerSB;

  // What does the player have in his inventory?
  numberRoL = mainChar.getRoL();
  numberRoS = mainChar.getRoS();
  hasSword = mainChar.getSword();
  hasDagger = mainChar.getDagger();
  hasShieldS = mainChar.getSmall();
  hasShieldL = mainChar.getLarge();
  hasPlate = mainChar.getPlate();
  hasLeather = mainChar.getLeather();

  // switch to determine what the item is and if it can be picked up
  switch(content) {
  case 0: // try to pick up in an empty tile
    cout << "\nWhat do you want to pick up here? Some grass?\n" << endl;
    break;
  case 6: // try to pick up a sword
    // set the item to a sword
    itemToPick.setItem(Type::SWORD);

    //What are the stats of the item?
    itemAttack = itemToPick.getItemAttack();
    itemWeight = itemToPick.getItemWeight();

    // if the player don't have already a weapon
    if (!hasSword && !hasDagger) {
      // if the player has enought strength to carry the item
      if (itemWeight+weightPlayer <= strengthPlayer) {
	mainChar.setSword(true);
	mainChar.setATTB(itemAttack+playerAB);
	mainChar.setWeight(itemWeight+weightPlayer);
	actionSuccess = true;

	// if player can carry sword print
	cout << "\nNow you have a sword! Please don't cut yourself with it though...\n" << endl;

	// if player can not carry sword due to lack of strength print 
      } else {
	cout << "\nYou don't have enougth strength, time to hit the gym!\n" << endl;
      }
      // if player can not carry sword due to already having weapon
    } else {
      cout << "\nYour already have a weapon, don't be too greedy\n" << endl;
    }
    break;
  case 7: // try to pick up a dagger
    // set the item to a dagger
    itemToPick.setItem(Type::DAGGER);

    //What are the stats of the item?
    itemAttack = itemToPick.getItemAttack();
    itemWeight = itemToPick.getItemWeight();

    // if the player doesn't already have a weapon
    if (!hasSword && !hasDagger) {
      // if the player has enought strength to carry the item
      if (itemWeight+weightPlayer <= strengthPlayer) {
	mainChar.setDagger(true);
	mainChar.setATTB(itemAttack+playerAB);
	mainChar.setWeight(itemWeight+weightPlayer);
	actionSuccess = true;

	// print if can carry dagger
	cout << "\nNow you have a dagger! I think it could be a good toothpick...\n" << endl;
	// print if can't carry dagger due to strength
      } else {
	cout << "\nYou don't have enougth strength, time to hit the gym!\n" << endl;
      }
      // print if you can't pick up dagger due to already carryng a weapon
    } else {
      cout << "\nYour already have a weapon, don't be too greedy\n" << endl;
    }
    break;
  case 8: // try to pick up a plate armor
    // set the item to a plate armor
    itemToPick.setItem(Type::PLATE);

    //What are the stats of the item?
    itemAttack = itemToPick.getItemAttack();
    itemDefence = itemToPick.getItemDefence();
    itemWeight = itemToPick.getItemWeight();

    // if the player don't have already an armor
    if (!hasPlate && !hasLeather) {
      // if the player has enought strength to carry the item
      if (itemWeight+weightPlayer <= strengthPlayer) {
	mainChar.setPlate(true);
	mainChar.setATTB(itemAttack+playerAB);
	mainChar.setDEFB(itemDefence+playerDB);
	mainChar.setWeight(itemWeight+weightPlayer);
	actionSuccess = true;

	// print if can pick up plate armour
	cout << "\nNow you have a plate armor! I see a little bit of rust on it...\n" << endl;

	// print if can't pick up plate armour due to strength
      } else {
	cout << "\nYou don't have enougth strength, time to hit the gym!\n" << endl;
      }
      // print if already have armour
    } else {
      cout << "\nYour already have an armor, don't be too greedy\n" << endl;
    }
    break;
  case 9: // try to pick up a leather armor
    // set the item to a leather armor
    itemToPick.setItem(Type::LEATHER);

    //What are the stats of the item?
    itemDefence = itemToPick.getItemDefence();
    itemWeight = itemToPick.getItemWeight();

    // if the player don't have already an armor
    if (!hasPlate && !hasLeather) {
      // if the player has enought strength to carry the item
      if (itemWeight+weightPlayer <= strengthPlayer) {
	mainChar.setLeather(true);
	mainChar.setDEFB(itemDefence+playerDB);
	mainChar.setWeight(itemWeight+weightPlayer);
	actionSuccess = true;

	// print if can pick up leather armour
	cout << "\nNow you have a leather armor! Is it really effective?\n" << endl;

	// print if can't pick up leather armour due to strength
      } else {
	cout << "\nYou don't have enougth strength, time to hit the gym!\n" << endl;
      }
      // print if you already have armour
    } else {
      cout << "\nYour already have an armor, don't be too greedy\n" << endl;
    }
    break;
  case 10: // try to pick up a large shield
    // set the item to a large shield
    itemToPick.setItem(Type::LARGESHIELD);

    //What are the stats of the item?
    itemAttack = itemToPick.getItemAttack();
    itemDefence = itemToPick.getItemDefence();
    itemWeight = itemToPick.getItemWeight();

    // if the player don't have already a shield
    if (!hasShieldL && !hasShieldS) {
      // if the player has enought strength to carry the item
      if (itemWeight+weightPlayer <= strengthPlayer) {
	mainChar.setLarge(true);
	mainChar.setDEFB(itemDefence+playerDB);
	mainChar.setATTB(itemAttack+playerAB);
	mainChar.setWeight(itemWeight+weightPlayer);
	actionSuccess = true;

	// print if you pick up large shield
	cout << "\nNow you have a large shield! I can't see you behind it...\n" << endl;

	// print if you can't pick up large shield due to strength
      } else {
	cout << "\nYou don't have enougth strength, time to hit the gym!\n" << endl;
      }
      // print if you already have shield
    } else {
      cout << "\nYour already have a shield, don't be too greedy\n" << endl;
    }
    break;
  case 11: // try to pick up a small shield
    // set the item to a small shield
    itemToPick.setItem(Type::SMALLSHIELD);

    //What are the stats of the item?
    itemDefence = itemToPick.getItemDefence();
    itemWeight = itemToPick.getItemWeight();

    // if the player don't have already a shield
    if (!hasShieldL && !hasShieldS) {
      // if the player has enought strength to carry the item
      if (itemWeight+weightPlayer <= strengthPlayer) {
	mainChar.setSmall(true);
	mainChar.setDEFB(itemDefence+playerDB);
	mainChar.setWeight(itemWeight+weightPlayer);
	actionSuccess = true;

	// print if you can pick up small shield
	cout << "\nNow you have a small shield! Pretty sure it can be a good frisbee...\n" << endl;

	// print if you can't pick up due to strength
      } else {
	cout << "\nYou don't have enougth strength, time to hit the gym!\n" << endl;
      }
      //print if you can't pick up due to already having shield
    } else {
      cout << "\nYour already have a shield, don't be too greedy\n" << endl;
    }    
    break;
  case 12: // try to pick up a ring of life
    // set the item to a ring of life
    itemToPick.setItem(Type::ROL);

    //What are the stats of the item?
    itemHealth = itemToPick.getItemHealth();
    itemWeight = itemToPick.getItemWeight();

    // if the player has enought strength to carry the item
    if (itemWeight+weightPlayer <= strengthPlayer) {
      mainChar.setRoL(++numberRoL);
      mainChar.setHB(itemHealth+playerHB);
      mainChar.setWeight(itemWeight+weightPlayer);
      actionSuccess = true;

      // print if you can pick up ring of life
      cout << "\nNow you have a new ring of life! Do you feel more healthy?\n" << endl;

      // print if you can't pick up due to lack of strength
    } else {
      cout << "\nYou don't have enougth strength, time to hit the gym!\n" << endl;
    }
    break;
  case 13: // try to pick up a ring of strength
    // set the item to a ring of strength
    itemToPick.setItem(Type::ROS);

    //What are the stats of the item?
    itemStrength = itemToPick.getItemStrength();
    itemHealth = itemToPick.getItemHealth();
    itemWeight = itemToPick.getItemWeight();

    // if the player has enought strength to carry the item
    if (itemWeight+weightPlayer <= strengthPlayer) {
      mainChar.setRoS(++numberRoS);
      mainChar.setHB(itemHealth+playerHB);
      mainChar.setSB(itemStrength+playerSB);
      mainChar.setWeight(itemWeight+weightPlayer);
      actionSuccess = true;

      // print if you pick up ring of strength
      cout << "\nNow you have a new ring of strength! You are so muscular now!\n" << endl;

      // print if you can't pick up due to lack of strength
    } else {
      cout << "\nYou don't have enougth strength, time to hit the gym!\n" << endl;
    }
    break;
  default: // try to pick up a creature
    cout << "\nYou can't pickup a living being, you fool!\n" << endl;
  }
  return actionSuccess; // return successful move
}
/////////////////////////////////////////////////////////////////////////////
// function: drop(mainChar, tileContent)
// if on an empty tile you can decide what to drop from characters inventory
//
// parameter: Player &mainChar - players information
// parameter: tileContent - tile content number
// return: itemDropped - returns item number of content dropped
/////////////////////////////////////////////////////////////////////////////
int GamePlay::drop(Player &mainChar, int tileContent)
{
  // item used to modify the bonus stats of the player
  Items itemToDrop;

  // item stats
  int itemAttack, itemHealth, itemStrength, itemDefence, itemWeight;
  
  // used to return what item has been drop, or not
  int itemDroped;
  // booleans to know if a player has a specific item
  bool sword, dagger, plate, leather, small, large;
  // int to know if a player has some rings
  int numberRoL, numberRoS;
  // int to know the player weight
  int weightPlayer;
  // int to know player's bonus stats
  int playerAB, playerDB, playerHB, playerSB;
  // prompt the user for an equipment to drop
  char input;

  // retrieves player's weapon inventory
  sword = mainChar.getSword();
  dagger = mainChar.getDagger();
  // retrieves player's armor inventory
  plate = mainChar.getPlate();
  leather = mainChar.getLeather();
  // retrieves player's shield inventory
  small = mainChar.getSmall();
  large = mainChar.getLarge();
  // retrieves player's rings inventory
  numberRoL = mainChar.getRoL();
  numberRoS = mainChar.getRoS();
  // retrieves player's weight
  weightPlayer = mainChar.getWeight();
  // retrieves player's bonus stats
  playerAB = mainChar.getATTB();
  playerDB = mainChar.getDEFB();
  playerHB = mainChar.getHB();
  playerSB = mainChar.getSB();

  // clear the Linux terminal using ANSI Escape Sequences
  // for a better comprehension of the game
  cout << u8"\033[2J\033[1;1H";
  
  cout << "------------ DROP --------------\n" << endl;

  // if the player has something in his inventory
  if (sword || dagger || plate || leather || small || large || (numberRoL>0) || (numberRoS>0)) {
    // if the tile is empty we can drop an item there
    if (tileContent == 0) {
      // if the player has a weapon
      if (sword || dagger) {
	cout << "Do you want to get rid of your weapon?\n"
	     << "Please press 'W' to do so.\n" << endl;
      }
      // if the player has an armor
      if (plate || leather) {
	cout << "Do you want to get rid of your armor?\n"
	     << "Please press 'A' to do so.\n" << endl;
      }
      // if the player has a shield
      if (small || large) {
	cout << "Do you want to get rid of your shield?\n"
	     << "Please press 'S' to do so.\n" << endl;
      }
      // if the player has at least one ring of life
      if (numberRoL > 0) {
	cout << "Do you want to get rid of a ring of life?\n"
	     << "Please press 'L' to do so.\n" << endl;
      }
      // if the player has at least one ring of strength
      if (numberRoS > 0) {
	cout << "Do you want to get rid of a ring of strength?\n"
	     << "Please press 'R' to do so.\n" << endl;

	// if player wants to cancel
      }
      cout << "Press 'C' to cancel.\n"
	   << "What piece of equipment do you want to get rid of? ";
      cin >> input;

      // switch what type do you want to drop
      switch(input) {
	// weapon drop
      case 'w':
      case 'W':
	if (sword) {
	  // set the int of the item to be droped for the board
	  itemDroped = 6; // sword

	  // set the item needed to retrieve the stats 
	  itemToDrop.setItem(Type::SWORD);
	  // What are the stats of the item?
	  itemAttack = itemToDrop.getItemAttack();
	  itemWeight = itemToDrop.getItemWeight();

	  // update the stats of the player
	  mainChar.setSword(false);
	  mainChar.setATTB(playerAB-itemAttack);
	  mainChar.setWeight(weightPlayer-itemWeight);

	  // aknowledge the drop
	  cout << "\nYou have droped your weapon\n" << endl;
	} else {
	  // set the int of the item to be droped for the board
	  itemDroped = 7; // dagger

	  // set the item needed to retrieve the stats 
	  itemToDrop.setItem(Type::DAGGER);
	  // What are the stats of the item?
	  itemAttack = itemToDrop.getItemAttack();
	  itemWeight = itemToDrop.getItemWeight();

	  // update the stats of the player
	  mainChar.setDagger(false);
	  mainChar.setATTB(playerAB-itemAttack);
	  mainChar.setWeight(weightPlayer-itemWeight);
	  
	  // aknowledge the drop
	  cout << "\nYou have droped your weapon\n" << endl;
	}
	break;
	// armour drop
      case 'a':
      case 'A':
	if (plate) {
	  // set the int of the item to be droped for the board
	  itemDroped = 8; // plate armour

	  // set the item needed to retrieve the stats 
	  itemToDrop.setItem(Type::PLATE);
	  // What are the stats of the item?
	  itemAttack = itemToDrop.getItemAttack();
	  itemDefence = itemToDrop.getItemDefence();
	  itemWeight = itemToDrop.getItemWeight();

	  // update the stats of the player
	  mainChar.setPlate(false);
	  mainChar.setDEFB(playerDB-itemDefence);
	  mainChar.setATTB(playerAB-itemAttack);
	  mainChar.setWeight(weightPlayer-itemWeight);

	  // aknowledge the drop
	  cout << "\nYou have droped your armor\n" << endl;
	} else {
	  // set the int of the item to be droped for the board
	  itemDroped = 9; // leather armour

	  // set the item needed to retrieve the stats 
	  itemToDrop.setItem(Type::LEATHER);
	  // What are the stats of the item?
	  itemDefence = itemToDrop.getItemDefence();
	  itemWeight = itemToDrop.getItemWeight();

	  // update the stats of the player
	  mainChar.setLeather(false);
	  mainChar.setDEFB(playerDB-itemDefence);
	  mainChar.setWeight(weightPlayer-itemWeight);

	  // aknowledge the drop
	  cout << "\nYou have droped your armor\n" << endl;
	}
	break;
	// shield drop
      case 's':
      case 'S':
	if (large) {
	  // set the int of the item to be droped for the board
	  itemDroped = 10; // large shield

	  // set the item needed to retrieve the stats 
	  itemToDrop.setItem(Type::LARGESHIELD);
	  // What are the stats of the item?
	  itemAttack = itemToDrop.getItemAttack();
	  itemDefence = itemToDrop.getItemDefence();
	  itemWeight = itemToDrop.getItemWeight();

	  // update the stats of the player
	  mainChar.setLarge(false);
	  mainChar.setDEFB(playerDB-itemDefence);
	  mainChar.setATTB(playerAB-itemAttack);
	  mainChar.setWeight(weightPlayer-itemWeight);

	  // aknowledge the drop
	  cout << "\nYou have droped your shield\n" << endl;
	} else {
	  // set the int of the item to be droped for the board
	  itemDroped = 11; // small shield drop

	  // set the item needed to retrieve the stats 
	  itemToDrop.setItem(Type::SMALLSHIELD);
	  // What are the stats of the item?
	  itemDefence = itemToDrop.getItemDefence();
	  itemWeight = itemToDrop.getItemWeight();

	  // update the stats of the player
	  mainChar.setSmall(false);
	  mainChar.setDEFB(playerDB-itemDefence);
	  mainChar.setWeight(weightPlayer-itemWeight);

	  // aknowledge the drop
	  cout << "\nYou have droped your shield\n" << endl;
	}
	break;
	// ring of life drop
      case 'l':
      case 'L':
	// set the int of the item to be droped for the board
	itemDroped = 12; // ring of life
	// reduce the player's ring of life number by 1
	--numberRoL;

	// set the item needed to retrieve the stats 
	itemToDrop.setItem(Type::ROL);
	// What are the stats of the item?
	itemHealth = itemToDrop.getItemHealth();
	itemWeight = itemToDrop.getItemWeight();
	
	// update the stats of the player
	mainChar.setRoL(numberRoL);
	mainChar.setHB(playerHB-itemHealth);
	mainChar.setWeight(weightPlayer-itemWeight);

	// aknowledge the drop
	cout << "\nYou have droped a ring of life\n" << endl;
	break;
	// ring of strength drop
      case 'r':
      case 'R':
	// set the int of the item to be droped for the board
	itemDroped = 13; // ring of strength
	// reduce the player's ring of life number by 1
	--numberRoS;

	// set the item needed to retrieve the stats 
	itemToDrop.setItem(Type::ROS);
	// What are the stats of the item?
	itemStrength = itemToDrop.getItemStrength();
	itemHealth = itemToDrop.getItemHealth();
	itemWeight = itemToDrop.getItemWeight();
	
	// update the stats of the player
	mainChar.setRoS(numberRoS);
	mainChar.setSB(playerSB-itemStrength);
	mainChar.setHB(playerHB-itemHealth);
	mainChar.setWeight(weightPlayer-itemWeight);

	// aknowledge the drop
	cout << "\nYou have droped a ring of strength\n" << endl;

	// cancel
	break;
      case 'c':
      case 'C':
      default:
	// if we return 0 in Main.cpp, indicates that the player could not drop items here
	itemDroped = 0;
      }
      
    } else { // if there is something already on the tile
      // if we return 0 in Main.cpp, indicates that the player could not drop items here
      itemDroped = 0;
      cout << "There is already something in here so you can't drop anything. Don't ask why.\n" << endl;
    }
  } else { // if the player has nothing in his inventory
    // if we return 0 in Main.cpp, indicates that the player could not drop items here
    itemDroped = 0;
    cout << "You don't have any equipment, what do you want to drop? your clothes?\n" << endl;
  }
  
  return itemDroped; // returns tile number of dropped item, if 0 not dropped
}

/////////////////////////////////////////////////////////////////////////////
// function: look(tileContent, enemy)
// Looks at what is on the tile and returns information on it
//
// parameter: int tileContent - the enemy on item tile number
// parameter: Character enemy - information on the enemy to print
// return: void
/////////////////////////////////////////////////////////////////////////////
void GamePlay::look(int tileContent, Character enemy)
{
  // used to return information on items
  Items item;

  // clear the Linux terminal using ANSI Escape Sequences
  // for a better comprehension of the game
  cout << u8"\033[2J\033[1;1H";
  
  cout << "------------ LOOK --------------\n" << endl;

  // switch to change tile content number to information
  switch(tileContent) {
  case 0: // empty
    cout << "Why are you looking at the grass?" << endl;
    break;
    // characters
  case 1: // human
  case 2: // elf
  case 3: // hobbit
  case 4: // dwarf
  case 5: // orc
    // function to update enemy's stats if it is an orc
    // depending of the time
    enemy.dayNightOrc(day);
    enemy.printCharac();
    break;
    // items
  case 6: // sword
    item.setItem(Type::SWORD);
    item.printItems(tileContent);
    break;
  case 7: // dagger
    item.setItem(Type::DAGGER);
    item.printItems(tileContent);
    break;
  case 8: // plate armour
    item.setItem(Type::PLATE);
    item.printItems(tileContent);
    break;
  case 9: // leather armour
    item.setItem(Type::LEATHER);
    item.printItems(tileContent);
    break;
  case 10: // large shield
    item.setItem(Type::LARGESHIELD);
    item.printItems(tileContent);
    break;
  case 11: // small shield
    item.setItem(Type::SMALLSHIELD);
    item.printItems(tileContent);
    break;
  case 12: // ring of life
    item.setItem(Type::ROL);
    item.printItems(tileContent);
    break;
  case 13: // ring of strength
    item.setItem(Type::ROS);
    item.printItems(tileContent);
    break;
  default:
  break;
  }
}

/////////////////////////////////////////////////////////////////////////////
// function: inventory(mainPlayer)
// brings up and displays the information of the players inventory
//
// parameter: Player mainPlayer - retrieves the stored inventory
// return: void
/////////////////////////////////////////////////////////////////////////////
void GamePlay::inventory(Player mainPlayer)
{
  // used to return information on items
  Items item;

  // clear the Linux terminal using ANSI Escape Sequences
  // for a better comprehension of the game
  cout << u8"\033[2J\033[1;1H";
  
  cout << "------------ INVENTORY --------------\n" << endl;

  // if player has sword print information about sword
  if (mainPlayer.getSword()) {
    item.setItem(Type::SWORD);
    item.printItems(6);
  }
  // if player has dagger print information about dagger
  if (mainPlayer.getDagger()) {
    item.setItem(Type::DAGGER);
    item.printItems(7);
  }
  // if player has plate armour print information about plate armour
  if (mainPlayer.getPlate()) {
    item.setItem(Type::PLATE);
    item.printItems(8);
  }
  // if player has leather armour print information about leather armour
  if (mainPlayer.getLeather()) {
    item.setItem(Type::LEATHER);
    item.printItems(9);
  }
  // if player has large shield print information about large shield
  if (mainPlayer.getLarge()) {
    item.setItem(Type::LARGESHIELD);
    item.printItems(10);
  }
  // if player has small shield print information about small shield
  if (mainPlayer.getSmall()) {
    item.setItem(Type::SMALLSHIELD);
    item.printItems(11);
  }
  // if player has ring of life print information about ring of life and amount
  if (mainPlayer.getRoL() > 0) {
    item.setItem(Type::ROL);
    // print number of ring of lives and stats
    cout << "You have: " << mainPlayer.getRoL() << " ";
    item.printItems(12);
  }
  // if player has ring of strength print information about ring of strength
  if (mainPlayer.getRoS() > 0) {
    item.setItem(Type::ROS);
    // print number of ring of strengths and stats
    cout << "You have: " << mainPlayer.getRoS() << " ";
    item.printItems(13);
  }
  // print information on amount of gold
  cout << "You currently have: " << mainPlayer.getGold() << " gold coins" << endl;
}

/////////////////////////////////////////////////////////////////////////////
// function: combat(mainChar, enemy)
// this function contains the attack part of the game
//
// parameter: Player &mainChar - information about the main character (player)
// parameter: Character &enemy - information on the enemy
// return: int return - result of the attack
/////////////////////////////////////////////////////////////////////////////
int GamePlay::combat(Player &mainChar, Character &enemy)
{
  RandomGenerator generator; // random generator for attack or defence chance
  int test; // used to see if an action is a success
  int damage; // used to calculate the damage
  
  /****************
   * PLAYER STATS *
   ****************/
  
  // Int to know player's stats
  int playerAtt, playerDef, playerHealth, playerGold;
  // Double to know player's attack and defence chances
  double playerAttCh, playerDefCh;
  // Int to know player's bonus stats
  int playerAB, playerDB, playerHB;

  // retrieve player's stats
  playerAtt = mainChar.getAttack();
  playerDef = mainChar.getDefence();
  playerHealth = mainChar.getHealth();
  playerGold = mainChar.getGold();
  
  // retrieve player's chances
  playerAttCh = mainChar.getAttChance();
  playerDefCh = mainChar.getDefChance();

  // retrieve player's bonus stats
  playerAB = mainChar.getATTB();
  playerDB = mainChar.getDEFB();
  playerHB = mainChar.getHB();
  
   /***************
   * ENEMY STATS *
   ***************/

  // Updates enemy's stats depending of the time
  // if it is an Orc
  enemy.dayNightOrc(day);
  
  // Int to know enemy's stats
  int enemyAtt, enemyDef, enemyHealth;
  // Double to know enemy's attack and defence chances
  double enemyAttCh, enemyDefCh;

  // retrieve enemy's stats
  enemyAtt = enemy.getAttack();
  enemyDef = enemy.getDefence();
  enemyHealth = enemy.getHealth();
  
  // retrieve enemy's chances
  enemyAttCh = enemy.getAttChance();
  enemyDefCh = enemy.getDefChance();
  
  // clear the Linux terminal using ANSI Escape Sequences
  // for a better comprehension of the game
  cout << u8"\033[2J\033[1;1H";
  
  cout << "------------ ATTACK --------------\n" << endl;

  // First, the player attack
  
  // attack test for player
  test = generator.combatGenerator();
  cout << "the test result is: " << test << endl;
  // if attack != succes
  if (test >= playerAttCh) {
    // do not attack
    cout << "You failed your attack, you are weak!\n" << endl;
    // enemy attack test
    test = generator.combatGenerator();
    cout << "the test result is: " << test << endl;
    if (test >= enemyAttCh) {
      cout << "The enemy missed you, what a muppet!\n" << endl;
      // The combat ends without any death
      return 0; // nobody dies
    } else { // if the enemy hits the player
      // player defence test
      test = generator.combatGenerator();
      cout << "the test result is: " << test << endl;
      if (test >= playerDefCh) { // if the player fails its defence
	// damage calculated depending on enemy attack and player defence
	damage = enemyAtt - (playerDef + playerDB);
	// update the health of the player
	playerHealth -= damage;
	mainChar.setHealth(playerHealth);
      } else {
	// damage calculated depending on the race special ability
	specialAbility(mainChar, enemy, false);
      }
      // if nobody dies
      if (playerHealth + playerHB > 0) {
	return 0; // nobody dies
	// if player dies
      } else {
	cout << "Dear Lord! You are dead!\n"
	     << "And you had " << playerGold << " gold coins on you... Now they're mine!\n"
	     << endl;
	return 2; // player dies
      }
    }
  } else {
    // defence test for the enemy
    test = generator.combatGenerator();
    cout << "the test result is: " << test << endl;
    if (test >= enemyDefCh) { // successful attack
      damage = playerAtt + playerAB - enemyDef; // damage is player attack + player attack bonus
      enemyHealth -= damage; // remove damage from enemy health
      enemy.setHealth(enemyHealth); // set enemy health
      cout << "You've dealt " << damage << " damage to the enemy, well done!\n" << endl;      
    } else {
      // damage calculated depending on the race special ability
      specialAbility(mainChar, enemy, true);
    }
    if (enemyHealth <= 0) {
      // the player gain the enemy defence in gold
      playerGold += enemyDef; // caluculate amount of gold
      mainChar.setGold(playerGold); // sets amount of gold
      cout << "The enemy has fallen, you hearned: " << enemyDef << " gold coins!" << endl;
      return 1; // the combat ends on the death of the enemy
    } else { 
      // enemy attack test
      test = generator.combatGenerator(); //generates attak chance
      cout << "the test result is: " << test << endl;
      if (test >= enemyAttCh) { // if enemy attack is less they have missed
	cout << "The enemy missed you, what a muppet!\n" << endl;
	// The combat ends without any death
	return 0; // nobody dies
      } else { // if the enemy hits the player
	// player defence test
	test = generator.combatGenerator();
	cout << "the test result is: " << test << endl;
	if (test >= playerDefCh) { // if the player fails its defence
	  // damage calculated depending on enemy attack and player defence
	  damage = enemyAtt - (playerDef + playerDB);
	  // update the health of the player
	  playerHealth -= damage;
	  mainChar.setHealth(playerHealth);
	} else {
	  // damage calculated depending on the race special ability
	  specialAbility(mainChar, enemy, false);
	}
	if (playerHealth + playerHB > 0) {
	  return 0; // nobody dies
	} else {
	  // if you die returns amount of gold on screen
	  cout << "Dear Lord! You are dead!\n"
	       << "And you had " << playerGold << " gold coins on you... Now they're mine!\n"
	       <<endl;
	  return 2; // player died
	}
      }
    }
  }
}

//////////////////////////////////////////////////////////////////////////
// function specialAbility(Player &mainChar, Character &enemy, bool attacker)
// function to define the consequences of a successful defence
// depending of the race of the defender
//
// parameters:
//        &mainChar - reference for the player (class Player)
//        &enemy - reference for the enemy (class Character)
//        attacker - boolean to know if the player is the attacker or not
// return: void
//////////////////////////////////////////////////////////////////////////
void GamePlay::specialAbility(Player &mainChar, Character &enemy, bool attacker)
{
  // RandomGenerator object used for the Hobbit ability
  RandomGenerator generator;
  // Player's race
  Race playerRace;
  // enemy's race
  Race enemyRace;
  // statistics and bonus statisctics of the player
  int playerAtt, playerDef, playerHealth, playerAB, playerDB;
  // statistics of the enemy
  int enemyAtt, enemyDef, enemyHealth;
  // variable used for damage calculation
  int damage;

  // retrieve the race of the two opponents
  playerRace = mainChar.getRace();
  enemyRace = enemy.getRace();
  
  if (!attacker) { // if the player is the defender
    switch(playerRace) {
    case Race::HUMAN: // if the player is a Human
      // The player takes no damage
      cout << "Thanks to your human skills, you have perfectly block the enemy's attack!\n" << endl;
      break;
    case Race::ELF: // if the player is an Elf
      // The player gains 1 health instead of taking damage
      cout << "Thanks to elf magic, the enemy attack somehow healed you a little\n"
	   << "Such a strange power, I reckon!\n" << endl;
      // retrieve player's health and increasing it by 1
      playerHealth = mainChar.getHealth() + 1;
      // update the player's health
      mainChar.setHealth(playerHealth);
      break;
    case Race::DWARF: // if the player is a Dwarf
      // The player takes no damage
      cout << "Thanks to your dwarf skills, you have perfectly block the enemy's attack!\n" << endl;
      break;
    case Race::HOBBIT: // if the player is a Hobbit
      // The amount of damage is chosed randomly
      // using a function in the class RandomGenerator
      damage = generator.hobbitSpecialDamage();
      if (damage == 0) { // special message if the player takes no damage
	cout << "With you hobbit agility, you dodged the attack, impressive!\n" << endl;
      } else {
	// retrieve player's health
	playerHealth = mainChar.getHealth();
	// decrease player's health by the amount of damage
	playerHealth -= damage;
	// update player's health
	mainChar.setHealth(playerHealth);
	cout << "You somewhat dodged the attack, the enemy just scratched you!\n"
	     << "You received " << damage << " damage\n"
	     << endl;
      }
      break;
    case Race::ORC: // if the player is an Orc 
      // retreive player's defence, defence bonus and health
      playerDef = mainChar.getDefence();
      playerDB = mainChar.getDEFB();
      playerHealth = mainChar.getHealth();
      // retreive enemy's attack
      enemyAtt = enemy.getAttack();

      // the special ability of an orc change with the time
      // we can know if it is day or night by looking at the boolean day
      if (day) { // if it is daytime
	// the player take 1/4 of the enemy's attack
	damage = (enemyAtt - playerDef - playerDB)/4;
	// reduce player health by the absolute value of damage
	// to avoid double negative
	playerHealth -= abs(damage);
	// update player's health
	mainChar.setHealth(playerHealth);
	cout << "Thanks to you Orc's thick skin, you received less damage!\n"
	     << "Only: " << abs(damage) << " damage\n"
	     <<"\"Tis but a scratch\" as would say one of my friend\n" << endl;
      } else { // if it is nightime
	// the health of the player's increase by one instead of taking damage
	++playerHealth;
	// Update player's health
	mainChar.setHealth(playerHealth);
	cout << "With the dark power of the night, the enemy attack healed you a little bit!\n"
	     << "Thanks Sauron!\n" << endl;
      }
      break;
    }
  } else { // if the player is the attacker
    switch(enemyRace) {
    case Race::HUMAN: // if the enemy is a Human
      // The enemy takes no damage
      cout << "Human are really good with a blade innit? He has blocked your attack!\n" << endl;
      break;
    case Race::ELF: // if the enemy is an Elf
      // The enemy gains 1 health instead of taking damage
      cout << "Your attack healed him a little\n"
	   << "He's cheating!\n" << endl;
      // retrieves enemy's health and increment it by 1
      enemyHealth = enemy.getHealth() + 1;
      // update enemy health
      enemy.setHealth(enemyHealth);
      break;
    case Race::DWARF: // if the enemy is a Dwarf
      // The enemy takes no damage
      cout << "This Dwarf know how to brawl! He just blocked you attack as if it was nothing\n" << endl;
      break;
    case Race::HOBBIT: // if the enemy is a hobbit
      // The amount of damage is chosed randomly
      // using a function in the class RandomGenerator
      damage = generator.hobbitSpecialDamage();
      if (damage == 0) { // special message if the player takes no damage
	cout << "This pesky little hobbit dodged your attack!\n" << endl;
      } else {
	// retrieves enemy's health
	enemyHealth = enemy.getHealth();
	// decrease enemy's health by the amount of damage
	enemyHealth -= damage;
	// update enemy's health
	enemy.setHealth(enemyHealth);
	cout << "He almost dodged your attack.\n"
	     << "He received " << damage << " damage\n"
	     << endl;
      }
      break;
    case Race::ORC: // if the enemy is an Orc 
      // retreive player's attack and attack bonus
      playerAtt = mainChar.getAttack();
      playerAB = mainChar.getATTB();
      // retreive enemy's defence and health
      enemyDef = enemy.getDefence();
      enemyHealth = enemy.getHealth();

      // the special ability of an orc change with the time
      // we can know if it is day or night by looking at the boolean day
      if (day) { // if it is daytime
	// the enemy takes 1/4 of the player's attack
	damage = (playerAtt + playerAB - enemyDef)/4;
	// reduce enemy health by the absolute value of damage
	// to avoid double negative
	enemyHealth -= abs(damage);
	// update the enemy's health
	enemy.setHealth(enemyHealth);
	cout << "He's more resistant thant I thought!\n"
	     <<"He received less damage than expected\n"
	     << "Only: " << damage << " damage" << endl;
      } else { // if it is nightime
	// increase enemy's health by 1
	++enemyHealth;
	// update enemy's health
	enemy.setHealth(enemyHealth);
	cout << "With the dark power of the night, your attack healed the enemy!\n"
	     << "Damn you Sauron!\n" << endl;
      }
      break;
    }
  }
}
 
//////////////////////////////////////////////////////////////////////////
// function endTurn(bool actionSuccess)
// function for the end of turn. If the player made a successful action
// we go to the next turn.
// if the player failed its action, he is notified and we stay
// at the current turn
//
// parameter: actionSuccess - boolean to know if the player failed its action
// return: void
//////////////////////////////////////////////////////////////////////////
void GamePlay::endTurn(bool actionSuccess)
{
  if (actionSuccess) { // If the player made a successful action
    // The number of count it incremented by 1
    ++turnCount;
  } else { // if te player failed
    // separation line for better visibility
    cout << "\n---------------------------------------------\n" << endl;
    // notifying message
    cout << "\tFailed action or incorrect input entered!" << endl;
  }
}


