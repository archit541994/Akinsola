/********************************************
 * Characters.h
 * Header file for the "Character" Superclass
 *
 * author: Akinsola Akinduro
 * last modified: 2020-12-23
 ********************************************/

// ensure that the file is only called once
#ifndef CHARACTERS_H
#define CHARACTERS_H

// enum class for the race of the character
// as seen in the Date.h sample code
enum class Race {HUMAN, ELF, DWARF, HOBBIT, ORC};

// initialise the class Character
class Character
{
 public:
  ///////////////////
  // CONSTRUCTORS //
  /////////////////
  Character();
  Character(Race ethnicity);
  /////////////////
  // DESTRUCTOR //
  ///////////////
  virtual ~Character();
  ////////////////
  // ACCESSORS //
  //////////////
  inline int getAttack() const {return attack;}
  inline int getHealth() const {return health;}
  inline int getStrength() const {return strength;}
  inline int getDefence() const {return defence;}
  inline double getAttChance() const {return attackChance;}
  inline double getDefChance() const {return defenceChance;}
  inline Race getRace() const {return characRace;}
  //////////////
  // MUTATOR //
  ////////////
  // change the race and stats
  void setCharacter(Race newRace);
  // change Orc's stats depending of the time
  void dayNightOrc(bool day);
  inline void setHealth(int newHealth) {health = newHealth;}
  // OTHER METHODS
  // displays the stats
  void printCharac() const;
protected: // protected for inheritance
  int attack, health, strength, defence;
  double attackChance, defenceChance;
  Race characRace;
};

#endif
