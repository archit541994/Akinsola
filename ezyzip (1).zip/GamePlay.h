/**********************************************
 * GamePlay.h
 * Header file for the "GamePlay" class
 *
 * author: Akinsola Akinduro
 * last modified: 2020-12-23
 **********************************************/

// ensure the file is only called once
#ifndef GAMEPLAY_H
#define GAMEPLAY_H

// initialise other needed classes
#include "Player.h"
#include "Characters.h"

// initialise the class GamePlay
class GamePlay
{
public:
  //////////////////
  // CONSTRUCTOR //
  ////////////////
  GamePlay();
  /////////////////
  // DESTRUCTOR //
  ///////////////
  virtual ~GamePlay();
  ////////////////////
  // OTHER METHODS //
  //////////////////
  // set the main character race
  // (used to initialise the player in Main.cpp using class Player)
  Race characterSelect();
  // set the game difficulty
  // (used to initialise the board in the class GameBoard)
  int selectDifficulty();
  // set the number of columns for the board
  // (used to initialise the board in the class GameBoard)
  int selectColumns();
  // set the number of rows for the board
  // (used to initialise the board in the class GameBoard)
  int selectRows();
  // display to the player the details of every beginning of a turn
  char turnDetails(Player &mainChar, bool actionSuccess, int tileContent);
  // checks if the player can move
  int movement(char move, int position, int max);
  // change what is the current enemy for the player
  Character currentEnemy(int tileContent);
  // displays the details of what's on the current tile of the board
  void look(int tileContent, Character enemy);
  // displays the details of you inventory
  void inventory(Player mainPlayer);
  // checks if a player can pick up an object and update the inventory and stats of the player
  bool pickup(Player &mainChar, int content);
  // checks if a player can drop an object and update the inventory and stats of the player
  int drop(Player &mainChar, int tileContent);
  // make a combat round
  int combat(Player &mainChar, Character &enemy);
  // checks if the turn is ended
  void endTurn(bool actionSuccess);
private:
  // used to know the current number of count
  int turnCount;
  // used to know if it is daytime or not
  bool day; 
  // determine if it is time to switch to daytime or nightime
  void dayNightCycle(bool actionSuccess);
  // determine the result of a successful defence depending of the racial ability
  void specialAbility(Player &mainChar, Character &enemy, bool attacker);
};

#endif
