/////////////////////////////////////////////////////////////////
// Main.cpp
// AssignmentUnit 3
// The main file that calls other functions
//
//author: Akinsola Akinduro
//Date: 23.12.2020
/////////////////////////////////////////////////////////////////

// standard library list
#include <cstdlib>
#include <iostream>

// header files
#include "GameBoard.h"
#include "GamePlay.h"
#include "Player.h"
#include "Characters.h"

using namespace std;

// main function
int main()
{
  // declared functions
  char action;
  GamePlay gp;
  Race ethnicity;
  bool successfulAction = true;
  int combatResult;
  int gameDifficulty, maxColumns, maxRows;
  int columns, newColumns;
  int rows, newRows;
  int tileContent, newTileContent;
  Character enemy;

  // welcome message at start of game
  cout << "\n----------- WELCOME TO THE GAME -----------\n" << endl;

  // player select at start of game
  ethnicity = gp.characterSelect();
  Player mainCharacter(ethnicity);

  // select difficulty level at start of game
  gameDifficulty = gp.selectDifficulty();

  // choose the amount of columns you want in the game
  maxColumns = gp.selectColumns();

  // choose the amount of rows you want in the game
  maxRows = gp.selectRows();
  
  // clear the Linux terminal using ANSI Escape Sequences
  // for a better comprehension of the game
  cout << u8"\033[2J\033[1;1H";

  // create the board that contains the enemies, items and blanks
  GameBoard board(gameDifficulty, maxColumns, maxRows);
  board.initialise();
  
  // determine if an enemy is on the initial tile
  tileContent = board.getMap(0, 0);
  enemy = gp.currentEnemy(tileContent);

  // control of the player in the game
  bool gameOver = false; // when true ends game
  do {
    // get the position of character
    columns = mainCharacter.getPlayerColumns();
    rows = mainCharacter.getPlayerRows();

    // what enemy, item is on the tile the player is on
    tileContent = board.getMap(columns, rows);

    // the datils of the player
    action = gp.turnDetails(mainCharacter, successfulAction,tileContent);

    // select to move N, S, E, W, A, P, D, L, I, E
    switch(action) {
      // move north or south
    case 'n':
    case 'N':
    case 's':
    case 'S':
      // move the character to new position (columns)
      newColumns = gp.movement(action, columns, maxColumns);
      mainCharacter.setPlayerColumns(newColumns);

      // if moved to new position change on item / enemy board and get details
      if (columns != newColumns) {
	successfulAction = true; // successful move
	newTileContent = board.getMap(newColumns, rows);
	enemy = gp.currentEnemy(newTileContent);
      } else {
	// you can not move this direction due to end of map
	successfulAction = false;
	cout << "\nYou have bumped into an invisible wall\n" << endl;
      }
      break;
      // move East or West
    case 'e':
    case 'E':
    case 'w':
    case 'W':
      // move the character to the new position (row)
      newRows = gp.movement(action, rows, maxRows);
      mainCharacter.setPlayerRows(newRows);

      // if moved to new position change on item / enemy board
      if (rows != newRows) {
	successfulAction = true; //successful move 
	newTileContent = board.getMap(columns, newRows);
	enemy = gp.currentEnemy(newTileContent);
      } else {
	// you can not move this direction due to end of map
	successfulAction = false;
	cout << "\nYou have bumped into an invisible wall\n" << endl;
      }
      break;
      // attack
    case 'a':
    case 'A':
      switch(tileContent) {
	// 0 = empty if no enemy print comment
      case 0:
	cout << "The only menace here is a rabbit... Maybe we should keep our distance though\n" << endl;
	successfulAction = false; // if enemy return true
	break;
      case 1: // human
      case 2: // elf
      case 3: // hobbit
      case 4: // dwarf
      case 5: // elf
	successfulAction = true; // there is an enemy on the tile
	// combat with enemy
	combatResult = gp.combat(mainCharacter, enemy);
	if (combatResult == 2) { // if 2 lost all health
	  gameOver = true; // end game
	}
	break;
      default:
	// if any other number is an item return comment
	cout << "You can't fight an item! Are you related to Don Quichotte by any chance?\n" << endl;
	successfulAction = false; // false as you can only attack enemy
	break;
      }       
      break;
      // pick up
    case 'p':
    case 'P':
      // can what is on the square be picked up?
      successfulAction = gp.pickup(mainCharacter, tileContent);
      // If the player successfuly picked up an item:
      // set the current square to empty (value 0)
      if (successfulAction) {
	board.setTile(columns, rows, 0);
      }
      break;
      // drop
    case 'd':
    case 'D':
      // can something be dropped on the tile
      newTileContent = gp.drop(mainCharacter, tileContent);
      if (newTileContent == 0) { // if the player failed to drop an object
	successfulAction = false;
      } else { // if the player droped an object
	// update the content of the tile to the droped object's ID
	board.setTile(columns, rows, newTileContent);
	successfulAction = true;
      }
      break;
      // look
    case 'l':
    case 'L':
      // look at what is in the tile either enemy, item or empty
      gp.look(tileContent, enemy);
      successfulAction = true; // finished turn
      break;
      // inventory
    case 'i':
    case 'I':
      // look at characters inventory
      gp.inventory(mainCharacter);
      successfulAction = true; // finished turn
      break;
      // exit game
    case 'x':
    case 'X':
      gameOver = true; // game over true exit loop
      break;
    default:
      successfulAction = false; // not a correct choice if anything else entered
      break;
    }
    // adds to turn count
    gp.endTurn(successfulAction);
  } while (!gameOver);
  
  // clear the Linux terminal using ANSI Escape Sequences
  // for a better comprehension of the game
  cout << u8"\033[2J\033[1;1H";
  
  return EXIT_SUCCESS;
}
