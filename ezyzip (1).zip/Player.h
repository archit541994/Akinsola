/*******************************************************
 * Player.h
 * Header file for the subclass "Player", derived from
 * the superclass "Character"
 *
 * author: Akinsola Akinduro
 * last modified: 2020-12-20
 ********************************************************/

// ensure that the file is only called once
#ifndef PLAYERCHARACTER_H
#define PLAYERCHARACTER_H

// initialise the Superclass
#include "Characters.h"

// initialise the Player class, derived from Character class
class Player : public Character {
 public:
  ///////////////////
  // CONSTRUCTORS //
  /////////////////
  Player();
  Player(Race ethnicity);
  /////////////////
  // DESTRUCTOR //
  ///////////////
  virtual ~Player();
  ////////////////
  // ACCESSORS //
  //////////////
  // accessors to know if the position of the player
  inline int getPlayerColumns() const {return positionColumns;}
  inline int getPlayerRows() const {return positionRows;}
  // accessor to know the weight
  inline int getWeight() const {return weight;}
  // accessors to know if it has a weapon
  inline bool getSword() const {return hasSword;}
  inline bool getDagger() const {return hasDagger;}
  // accessors to know if it has a shield
  inline bool getSmall() const {return hasShieldS;}
  inline bool getLarge() const {return hasShieldL;}
  // accessors to know if it has an armor
  inline bool getPlate() const {return hasPlate;}
  inline bool getLeather() const {return hasLeather;}
  // accessors to know if it has rings
  inline int getRoL() const {return numberRoL;}
  inline int getRoS() const {return numberRoS;}
  // accessor to know if it has gold
  inline int getGold() const {return numberGold;}
  // accessors to knows if there are bonus stats
  inline int getATTB() const {return attackBonus;}
  inline int getDEFB() const {return defenceBonus;}
  inline int getHB() const {return healthBonus;}
  inline int getSB() const {return strengthBonus;}

   // MUTATOR
  // mutator to change the position of the player
  inline void setPlayerColumns(int newColumns) {positionColumns = newColumns;}
  inline void setPlayerRows(int newRows) {positionRows = newRows;}
  // mutator to change the weight
  inline void setWeight(int newWeight) {weight = newWeight;}
  // mutator to change if it has a weapon or not
  inline void setSword(bool newSword) {hasSword = newSword;}
  inline void setDagger(bool newDagger) {hasDagger = newDagger;}
  // mutator to change if it has a shield or not
  inline void setSmall(bool newSmall) {hasShieldS = newSmall;}
  inline void setLarge(bool newLarge) {hasShieldL = newLarge;}
  // mutator to change if it has an armor or not
  inline void setPlate(bool newPlate) {hasPlate = newPlate;}
  inline void setLeather(bool newLeather) {hasLeather = newLeather;}
  // mutator to change the number of rings
  inline void setRoL(int newRoL) {numberRoL = newRoL;}
  inline void setRoS(int newRoS) {numberRoS = newRoS;}
  // mutator to change the number of gold
  inline void setGold(int newGold) {numberGold = newGold;}
  // mutator to change if there are bonus stats
  inline void setATTB(int newAttBonus) {attackBonus = newAttBonus;}
  inline void setDEFB(int newDefBonus) {defenceBonus = newDefBonus;}
  inline void setHB(int newHBonus) {healthBonus = newHBonus;}
  inline void setSB(int newSBonus) {strengthBonus = newSBonus;}
  ////////////////////
  // OTHER METHODS //
  //////////////////
  void printPlayerStat() const;
 private:
  // booleans to know if the player has the items in his inventory
  // can only have one item for each of the following categories:
  // WEAPONS
  bool hasSword, hasDagger;
  // SHIELDS
  bool hasShieldS, hasShieldL;
  // ARMORS
  bool hasPlate, hasLeather;

  // integers to know the number of rings and gold the player has
  int numberRoL, numberRoS, numberGold;
  
  // indicates the position of the player on the board
  int positionColumns, positionRows;

  // indicate the weight of the equipment
  int weight;

  // bonuses stats granted by equipments
  int attackBonus, defenceBonus, healthBonus, strengthBonus;
};

#endif
