/**********************************************
 * GameBoard.h
 * Header file for the "GameBoard" class
 *
 * author: Akinsola Akinduro
 * last modified: 2020-12-20
 ***********************************************/

// ensure the the file is only called once
#ifndef GAMEBOARD_H
#define GAMEBOARD_H

#include "RandomGenerator.h"

// initialise the class GameBoard
class GameBoard
{
 public:
  ///////////////////
  // CONSTRUCTORS //
  /////////////////
  GameBoard();
  GameBoard(int select_diff, int columns, int rows);
  /////////////////
  // DESTRUCTOR //
  ///////////////
  virtual ~GameBoard();
  ////////////////
  // ACCESSORS //
  //////////////
  inline int getDifficulty() const {return difficulty;}
  inline int getMaxColumns() const {return maxColumns;}
  inline int getMaxRows() const {return maxRows;}
  inline int getMap(int columns, int rows) const {return worldMap[columns][rows];}
  //////////////
  // MUTATOR //
  ////////////
  // update the content of a square in the board
  inline void setTile(int columns, int rows, int newContent) {worldMap[columns][rows] = newContent;}
  ////////////////////
  // OTHER METHODS //
  //////////////////
  // initialisation of the board
  void initialise();     
 private:
  // define the ratio between ennemies and items
  int difficulty;
  // define the boarders of the map (<= 200)
  int maxColumns, maxRows;
  // 2D array for the map (max size: 200x200)
  int worldMap[200][200]; 
  
  // RandomGenerators class used for initialising the board
  RandomGenerator generator; // define what is in a tile
};

#endif
