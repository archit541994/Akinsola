/***********************************************
 * RandomGenerator.h
 * Header file for the "RandomGenerator" class
 *
 * author: Akinsola Akinduro
 * last modified: 2020-12-23
 ***********************************************/

// ensure that the file is only called once
#ifndef RANDOMGENERATOR_H
#define RANDOMGENERATOR_H

#include <cstdlib>

// initialse the class RandomGenerator
class RandomGenerator
{
 public:
  //////////////////
  // CONSTRUCTOR //
  ////////////////
  RandomGenerator(); 
  /////////////////
  // DESTRUCTOR //
  ///////////////
  ~RandomGenerator();
  //////////////////////
  // OTHER FUNCTIONS //
  ////////////////////
  // Determine if a tile of the board is empty or not 
  int boardGenerator(int difficulty);
  // Randomly generate a character (for creating enemy)
  int characterGenerator();
  // Randomly generate an item
  int itemGenerator();
  // Randomly chose if combat action is a success
  int combatGenerator();
  // Randomly chose the damage taken by a hobbit
  int hobbitSpecialDamage();
 private:
  // For generating a number between 1 and 100 (%)
  const int minVal = 1;
  const int maxVal = 100;
  // If random number between 1 and 5 --> character
  const int minCharacter = 1;
  const int maxCharacter = 5;
  // If random number between 6 and 13 --> item
  const int minItem = 6;
  const int maxItem = 13;
};

#endif
