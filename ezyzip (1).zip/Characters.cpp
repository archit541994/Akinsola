/*************************************************************
 * Characters.cpp
 * Superclass defining a basic character, with all its statistics,
 * a function to display the statistics and a function to
 * update the statistics of an orc
 *
 * author: Akinsola Akinduro
 * last modified: 2020-12-20
 *************************************************************/


#include <cstdlib>
#include <iostream>
#include <string>

#include "Characters.h"

using namespace std;

///////////////////
// CONSTRUCTORS //
/////////////////

// Default constructor
Character::Character()
  :attack(30), health(60), strength(100), defence(20),
   attackChance(67), defenceChance(50), characRace(Race::HUMAN)
{

}

// Custom constructor, depending of the race
Character::Character(Race ethnicity)
{
  characRace = ethnicity;  
  switch(ethnicity) {
  case Race::HUMAN: // if a Human
    attack = 30;
    attackChance = 67; // 67% chance or 2/3
    defence = 20;
    defenceChance = 50; // 50% chance or 1/2
    health = 60;
    strength = 100;
    break;
  case Race::ELF: // if an Elf
    attack = 40;
    attackChance = 100; // 100% chance
    defence = 10;
    defenceChance = 25; // 25% chance or 1/4
    health = 40;
    strength = 70;
    break;
  case Race::DWARF: // if a Dwarf
    attack = 30;
    attackChance = 67; // 67% chance or 2/3
    defence = 20;
    defenceChance = 67; // 67% chance or 2/3
    health = 50;
    strength = 130;
    break;
  case Race::HOBBIT: // if a Hobbit
    attack = 25;
    attackChance = 33; // 33% chance or 1/3
    defence = 20;
    defenceChance = 67; // 67% chance or 2/3
    health = 70;
    strength = 85;
    break;
  case Race::ORC: // if an Orc
    attack = 25;
    attackChance = 25; // 25% chance at daytime, or 1/4
    defence = 10;
    defenceChance = 25; // 25% chance at daytime, or 1/4
    health = 50;
    strength = 130;
    break;
  default:
    break;
  }
}

/////////////////
// DESTRUCTOR //
///////////////

Character::~Character()
{
  
}

///////////////
// MUTATORS //
/////////////

//////////////////////////////////////////////////////////////////////////
// function setCharacter(Race newRace)
// modify a character's race and stats
//
// parameter: newRace - Race type object, used to modifiy the race and stats
// return: void
//////////////////////////////////////////////////////////////////////////
void Character::setCharacter(Race newRace)
{
  // Update the race of the Character
  characRace = newRace;  
  // Change the statistics depending of the new race
  switch(newRace) {
  case Race::HUMAN: // if a Human
    attack = 30;
    attackChance = 67; // 67% chance or 2/3
    defence = 20;
    defenceChance = 50; // 50% chance or 1/2
    health = 60;
    strength = 100;
    break;
  case Race::ELF: // if an Elf
    attack = 40;
    attackChance = 100; // 100% chance
    defence = 10;
    defenceChance = 25; // 25% chance or 1/4
    health = 40;
    strength = 70;
    break;
  case Race::DWARF: // if a Dwarf
    attack = 30;
    attackChance = 67; // 67% chance or 2/3
    defence = 20;
    defenceChance = 67; // 67% chance or 2/3
    health = 50;
    strength = 130;
    break;
  case Race::HOBBIT: // if a Hobbit
    attack = 25;
    attackChance = 33; // 33% chance or 1/3
    defence = 20;
    defenceChance = 67; // 67% chance or 2/3
    health = 70;
    strength = 85;
    break;
  case Race::ORC: // if an Orc
    attack = 25;
    attackChance = 25; // 25% chance at daytime, or 1/4
    defence = 10;
    defenceChance = 25; // 25% chance at daytime, or 1/4
    health = 50;
    strength = 130;
    break;
  default:
    break;
  }
}

//////////////////////////////////////////////////////////////////////////
// function dayNightOrc(bool day)
// modify the statistics of an Orc, depending of the time of the day
//
// parameter: day - boolen, true == day, false == night
// return: void
//////////////////////////////////////////////////////////////////////////
void Character::dayNightOrc(bool day)
{
  if (characRace == Race::ORC && day) {
    attack = 25;
    attackChance = 25;
    defence = 10;
    defenceChance = 25;
  } else if (characRace == Race::ORC && !day) {
    attack = 45;
    attackChance = 100;
    defence = 25;
    defenceChance = 50;
  }
}

/////////////////////
// OTHER FUNCTION //
///////////////////

//////////////////////////////////////////////////////////////////////////
// function printCharac()
// Print the characteristics of a character
//
// parameter: N/A
// return: void
//////////////////////////////////////////////////////////////////////////
void Character::printCharac() const
{
  // Used to print the race of the character in a std::cout
  string raceChar;
  
  // characRace takes the race in string 
  switch(characRace) {
  case Race::HUMAN:
    raceChar = "Human";  
    break;
  case Race::ELF:
    raceChar = "Elf";
    break;
  case Race::DWARF:
    raceChar = "Dwarf";
    break;
  case Race::HOBBIT:
    raceChar = "Hobbit";
    break;
  case Race::ORC:
    raceChar = "Orc";
    break;
  default:
    break;
  }
 
  // Prints all characteristics using std::cout 
  cout << "Race: " << raceChar << endl;
  cout << "Attack: " << attack << ", Defence: " << defence
       << "\nAttack chance: " << attackChance << "%, Defence chance: " << defenceChance << "%"
       << "\nHealth: " << health << ", Strength: " << strength << endl;
}
