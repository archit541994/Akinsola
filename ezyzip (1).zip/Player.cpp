/*********************************************************************************
 * Player.cpp
 * Subclass defining a special Character: a Player that have additional statistics
 * and functions. 
 *
 * author: Akinsola Akinduro
 * last modified: 2020-12-23
 *********************************************************************************/

#include <cstdlib>
#include <iostream>
#include <string>

#include "Player.h"

using namespace std;

///////////////////
// CONSTRUCTORS //
/////////////////

// default constructor, calling the constructor of the Superclass Character
Player::Player()
  :Character(), hasSword(false), hasDagger(false), hasShieldS(false), hasShieldL(false),
   hasPlate(false), hasLeather(false), numberRoL(0), numberRoS(0), numberGold(0),
   positionColumns(0), positionRows(0)
{
  attackBonus = 0;
  defenceBonus = 0;
  healthBonus = 0;
  strengthBonus = 0;
  weight = 0;
}

// custom constructor, depending of the race of the player
// calls the superclass Character
Player::Player(Race ethnicity)
  :Character(ethnicity), hasSword(false), hasDagger(false), hasShieldS(false), hasShieldL(false),
   hasPlate(false), hasLeather(false), numberRoL(0), numberRoS(0), numberGold(0),
   positionColumns(0), positionRows(0)
{
  attackBonus = 0;
  defenceBonus = 0;
  healthBonus = 0;
  strengthBonus = 0;
  weight = 0;
}

/////////////////
// DESTRUCTOR //
///////////////

Player::~Player()
{

}

////////////////////
// OTHER METHODS //
//////////////////

//////////////////////////////////////////////////////////////////////////
// function printItem(int itemInt)
// Print the characteristics of the player, depending of it race

//
// parameter: N/A
// return: void
//////////////////////////////////////////////////////////////////////////
void Player::printPlayerStat() const
{
  // used to print the race of the player in std::cout
  string raceChar;
  
  switch(characRace) {
  case Race::HUMAN: // if a Human
    raceChar = "Human";  
    break;
  case Race::ELF: // if an Elf
    raceChar = "Elf";
    break;
  case Race::DWARF: // if a Dwarf
    raceChar = "Dwarf";
    break;
  case Race::HOBBIT: // if a Hobbit
    raceChar = "Hobbit";
    break;
  case Race::ORC: // if an Orc
    raceChar = "Orc";
    break;
  default:
    break;
  }
  
  // Prints the race, statistics, with the potential bonus of items, the weight of the inventory
  // and amount of gold of the player
  cout << "Race: " << raceChar << endl;
  cout << "Attack: " << attack + attackBonus << ", Defence: " << defence + defenceBonus
       << "\nAttack chance: " << attackChance << "%, Defence chance: " << defenceChance << "%"
       << "\nHealth: " << health + healthBonus << ", Strength: " << strength + strengthBonus << endl;
  cout << "Carrying: " << weight << "/" << strength + strengthBonus << endl;
  cout << "\nYou currently have " << numberGold << " gold coins" << endl;
}
