/********************************************
 * Items.h
 * Header file for the "Items" class
 *
 * author: Akinsola Akinduro
 ********************************************/

// ensure that the file is only called once
#ifndef ITEMS_H
#define ITEMS_H

// enum class for the type of item
// as seen in Date.h sample code
enum class Type {SWORD, DAGGER, PLATE, LEATHER, LARGESHIELD,
SMALLSHIELD, ROL, ROS};

// initialise the class Items
class Items
{
 public:
  ///////////////////
  // CONSTRUCTORS //
  /////////////////
  Items();
  Items(Type category);
  /////////////////
  // DESTRUCTOR //
  ///////////////
  virtual ~Items();
  ////////////////
  // ACCESSORS //
  //////////////
  inline int getItemAttack() const {return attackBonus;}
  inline int getItemHealth() const {return healthBonus;}
  inline int getItemStrength() const {return strengthBonus;}
  inline int getItemDefence() const {return defenceBonus;}
  inline int getItemWeight() const {return itemWeight;}
  //////////////
  // MUTATOR //
  ////////////
  // change the item type and stats
  void setItem(Type category);
  ////////////////////
  // OTHER METHODS //
  //////////////////
  // print the statistics of the item
  void printItems (int itemType) const;
 private:
  int attackBonus, healthBonus, strengthBonus, defenceBonus, itemWeight;
  Type itemType;
};

#endif
